# Naive Bayes Classifier for Hand-written Digit Classification

Datasets from [here](https://www.kaggle.com/oddrationale/mnist-in-csv). <br/>
Gives acuuracy of 84.12% on test data.
As, the data is directly used from the csv, it is to be noted that before try running the code, 1st row of the CSV file should be removed, i.e., the column names.
